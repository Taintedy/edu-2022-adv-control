.. autosummary::
   :template: module_custom_initial.rst
   :caption: Modules
   :toctree: modules
   :recursive:

   rcognita