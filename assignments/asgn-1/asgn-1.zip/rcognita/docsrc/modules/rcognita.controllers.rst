``rcognita.controllers`` 
========================


.. automodule:: rcognita.controllers

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: sub
   
      ctrl_selector
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: sub
   
      CtrlNominal3WRobot
      CtrlNominal3WRobotNI
      CtrlOptPred
      CtrlRLStab
   
   

   
   
   



