rcognita.utilities.rej\_sampling\_rvs
=====================================

.. currentmodule:: rcognita.utilities

.. autofunction:: rej_sampling_rvs