rcognita.models.ModelNN
=======================

.. currentmodule:: rcognita.models

.. autoclass:: ModelNN

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ModelNN.__init__
   
   

   
   
   