rcognita.utilities.on\_key\_press
=================================

.. currentmodule:: rcognita.utilities

.. autofunction:: on_key_press