rcognita.loggers.Logger2Tank
============================

.. currentmodule:: rcognita.loggers

.. autoclass:: Logger2Tank

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Logger2Tank.__init__
      ~Logger2Tank.log_data_row
      ~Logger2Tank.print_sim_step
   
   

   
   
   