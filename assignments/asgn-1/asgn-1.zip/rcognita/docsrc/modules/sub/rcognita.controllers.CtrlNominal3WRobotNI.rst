rcognita.controllers.CtrlNominal3WRobotNI
=========================================

.. currentmodule:: rcognita.controllers

.. autoclass:: CtrlNominal3WRobotNI

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CtrlNominal3WRobotNI.__init__
      ~CtrlNominal3WRobotNI.compute_LF
      ~CtrlNominal3WRobotNI.compute_action
      ~CtrlNominal3WRobotNI.compute_action_vanila
      ~CtrlNominal3WRobotNI.reset
   
   

   
   
   