rcognita.utilities.upd\_line
============================

.. currentmodule:: rcognita.utilities

.. autofunction:: upd_line