rcognita.utilities.DFilter
==========================

.. currentmodule:: rcognita.utilities

.. autoclass:: DFilter

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DFilter.__init__
      ~DFilter.filt
   
   

   
   
   