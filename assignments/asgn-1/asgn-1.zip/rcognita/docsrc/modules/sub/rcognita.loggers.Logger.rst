rcognita.loggers.Logger
=======================

.. currentmodule:: rcognita.loggers

.. autoclass:: Logger

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Logger.__init__
      ~Logger.log_data_row
      ~Logger.print_sim_step
   
   

   
   
   