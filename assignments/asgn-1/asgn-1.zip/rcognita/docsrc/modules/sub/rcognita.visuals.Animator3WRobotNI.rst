rcognita.visuals.Animator3WRobotNI
==================================

.. currentmodule:: rcognita.visuals

.. autoclass:: Animator3WRobotNI

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Animator3WRobotNI.__init__
      ~Animator3WRobotNI.animate
      ~Animator3WRobotNI.get_anm
      ~Animator3WRobotNI.init_anim
      ~Animator3WRobotNI.set_sim_data
      ~Animator3WRobotNI.stop_anm
      ~Animator3WRobotNI.upd_sim_data_row
   
   

   
   
   