rcognita.systems.Sys3WRobotNI
=============================

.. currentmodule:: rcognita.systems

.. autoclass:: Sys3WRobotNI

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Sys3WRobotNI.__init__
      ~Sys3WRobotNI.closed_loop_rhs
      ~Sys3WRobotNI.out
      ~Sys3WRobotNI.receive_action
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Sys3WRobotNI.name
   
   