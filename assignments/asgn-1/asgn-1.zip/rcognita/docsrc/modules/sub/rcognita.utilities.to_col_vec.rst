rcognita.utilities.to\_col\_vec
===============================

.. currentmodule:: rcognita.utilities

.. autofunction:: to_col_vec