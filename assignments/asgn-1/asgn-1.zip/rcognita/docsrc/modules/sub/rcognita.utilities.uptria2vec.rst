rcognita.utilities.uptria2vec
=============================

.. currentmodule:: rcognita.utilities

.. autofunction:: uptria2vec