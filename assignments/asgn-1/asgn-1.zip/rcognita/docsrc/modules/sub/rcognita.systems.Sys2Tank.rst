rcognita.systems.Sys2Tank
=========================

.. currentmodule:: rcognita.systems

.. autoclass:: Sys2Tank

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Sys2Tank.__init__
      ~Sys2Tank.closed_loop_rhs
      ~Sys2Tank.out
      ~Sys2Tank.receive_action
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Sys2Tank.name
   
   