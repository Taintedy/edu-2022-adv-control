rcognita.utilities.reset\_line
==============================

.. currentmodule:: rcognita.utilities

.. autofunction:: reset_line