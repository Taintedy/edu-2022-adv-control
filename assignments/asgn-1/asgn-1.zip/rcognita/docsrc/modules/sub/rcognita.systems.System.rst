rcognita.systems.System
=======================

.. currentmodule:: rcognita.systems

.. autoclass:: System

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~System.__init__
      ~System.closed_loop_rhs
      ~System.out
      ~System.receive_action
   
   

   
   
   