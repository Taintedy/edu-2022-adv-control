rcognita.visuals.Animator3WRobot
================================

.. currentmodule:: rcognita.visuals

.. autoclass:: Animator3WRobot

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Animator3WRobot.__init__
      ~Animator3WRobot.animate
      ~Animator3WRobot.get_anm
      ~Animator3WRobot.init_anim
      ~Animator3WRobot.set_sim_data
      ~Animator3WRobot.stop_anm
      ~Animator3WRobot.upd_sim_data_row
   
   

   
   
   