rcognita.visuals.Animator
=========================

.. currentmodule:: rcognita.visuals

.. autoclass:: Animator

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Animator.__init__
      ~Animator.animate
      ~Animator.get_anm
      ~Animator.init_anim
      ~Animator.stop_anm
   
   

   
   
   