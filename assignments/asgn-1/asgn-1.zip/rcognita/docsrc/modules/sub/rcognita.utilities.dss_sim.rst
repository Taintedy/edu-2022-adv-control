rcognita.utilities.dss\_sim
===========================

.. currentmodule:: rcognita.utilities

.. autofunction:: dss_sim