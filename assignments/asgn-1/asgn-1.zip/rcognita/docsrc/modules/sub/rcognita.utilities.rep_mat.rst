rcognita.utilities.rep\_mat
===========================

.. currentmodule:: rcognita.utilities

.. autofunction:: rep_mat