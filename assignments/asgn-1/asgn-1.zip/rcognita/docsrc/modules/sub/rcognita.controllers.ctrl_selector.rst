rcognita.controllers.ctrl\_selector
===================================

.. currentmodule:: rcognita.controllers

.. autofunction:: ctrl_selector