rcognita.visuals.Animator2Tank
==============================

.. currentmodule:: rcognita.visuals

.. autoclass:: Animator2Tank

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Animator2Tank.__init__
      ~Animator2Tank.animate
      ~Animator2Tank.get_anm
      ~Animator2Tank.init_anim
      ~Animator2Tank.set_sim_data
      ~Animator2Tank.stop_anm
      ~Animator2Tank.upd_sim_data_row
   
   

   
   
   