``rcognita.visuals`` 
====================


.. automodule:: rcognita.visuals

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: sub
   
      Animator
      Animator2Tank
      Animator3WRobot
      Animator3WRobotNI
      RobotMarker
   
   

   
   
   



