``rcognita.utilities`` 
======================


.. automodule:: rcognita.utilities

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: sub
   
      dss_sim
      on_key_press
      push_vec
      rej_sampling_rvs
      rep_mat
      reset_line
      to_col_vec
      upd_line
      upd_scatter
      upd_text
      uptria2vec
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: sub
   
      DFilter
      ZOH
   
   

   
   
   



