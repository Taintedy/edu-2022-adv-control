Open the jupyter notebook *asgn-1.ipynb*. All the instructions are there.
