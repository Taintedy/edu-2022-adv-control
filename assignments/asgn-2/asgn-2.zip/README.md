In this assignment you will implement an MPC controller and see the result on a digital implementation of a turtle bot. 

Just launch MPC_asgn_2.ipynb notebook with Anaconda (preferably, due to Latex and Markdown rendering stability issues) and follow the instructions.

In case of problems don't hesitate to contact Ilya Osokin (@elijahmipt) or Georgiy Malaniya (@OdinManiac)