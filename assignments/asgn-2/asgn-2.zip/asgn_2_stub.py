import numpy as np

from rcognita.rcognita import simulator
from rcognita.rcognita import systems
from rcognita.rcognita import controllers
from rcognita.rcognita import loggers
from rcognita.rcognita import visuals
from rcognita.rcognita.utilities import on_key_press
from rcognita.rcognita.utilities import dss_sim
from rcognita.rcognita.utilities import rep_mat
from rcognita.rcognita.utilities import uptria2vec
from rcognita.rcognita.utilities import push_vec
import argparse


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ("yes", "true", "t", "y", "1"):
        return True
    elif v.lower() in ("no", "false", "f", "n", "0"):
        return False
    else:
        raise argparse.ArgumentTypeError("Boolean value expected.")


description = "Agent-environment preset: a 3-wheel robot (kinematic model a. k. a. non-holonomic integrator)."

parser = argparse.ArgumentParser(description=description)

parser.add_argument(
    "--ctrl_mode",
    metavar="ctrl_mode",
    type=str,
    choices=["manual", "nominal", "MPC", "RQL", "SQL", "JACS"],
    default="MPC",
    help="Control mode. Currently available: "
    + "----manual: manual constant control specified by action_manual; "
    + "----nominal: nominal controller, usually used to benchmark optimal controllers;"
    + "----MPC:model-predictive control; "
    + "----RQL: Q-learning actor-critic with Nactor-1 roll-outs of stage objective; "
    + "----SQL: stacked Q-learning; "
    + "----JACS: joint actor-critic (stabilizing), system-specific, needs proper setup.",
)
parser.add_argument(
    "--dt", type=float, metavar="dt", default=0.01, help="Controller sampling time."
)
parser.add_argument(
    "--t1", type=float, metavar="t1", default=10.0, help="Final time of episode."
)
parser.add_argument(
    "--Nruns",
    type=int,
    default=1,
    help="Number of episodes. Learned parameters are not reset after an episode.",
)
parser.add_argument(
    "--state_init",
    type=str,
    nargs="+",
    metavar="state_init",
    default=["5", "5", "-3*pi/4"],
    help="Initial state (as sequence of numbers); "
    + "dimension is environment-specific!",
)
parser.add_argument(
    "--is_log_data",
    type=str2bool,
    default=False,
    help="Flag to log data into a data file. Data are stored in simdata folder.",
)
parser.add_argument(
    "--is_visualization",
    type=str2bool,
    nargs="?",
    const=True,
    default=True,
    help="Flag to produce graphical output.",
)
parser.add_argument(
    "--is_print_sim_step",
    type=str2bool,
    default=True,
    help="Flag to print simulation data into terminal.",
)
parser.add_argument(
    "--prob_noise_pow",
    type=float,
    default=False,
    help="Power of probing (exploration) noise.",
)
parser.add_argument(
    "--action_manual",
    type=float,
    default=[-5, -3],
    nargs="+",
    help="Manual control action to be fed constant, system-specific!",
)
parser.add_argument(
    "--Nactor",
    type=int,
    default=3,
    help="Horizon length (in steps) for predictive controllers.",
)
parser.add_argument(
    "--pred_step_size_multiplier",
    type=float,
    default=1.0,
    help="Size of each prediction step in seconds is a pred_step_size_multiplier multiple of controller sampling time dt.",
)
parser.add_argument(
    "--stage_obj_struct",
    type=str,
    default="quadratic",
    choices=["quadratic", "biquadratic"],
    help="Structure of stage objective function.",
)
parser.add_argument(
    "--R1_diag",
    type=float,
    nargs="+",
    default=[1, 10, 1, 0, 0],
    help="Parameter of stage objective function. Must have proper dimension. "
    + "Say, if chi = [observation, action], then a quadratic stage objective reads chi.T diag(R1) chi, where diag() is transformation of a vector to a diagonal matrix.",
)
parser.add_argument(
    "--R2_diag",
    type=float,
    nargs="+",
    default=[1, 10, 1, 0, 0],
    help="Parameter of stage objective function . Must have proper dimension. "
    + "Say, if chi = [observation, action], then a bi-quadratic stage objective reads chi**2.T diag(R2) chi**2 + chi.T diag(R1) chi, "
    + "where diag() is transformation of a vector to a diagonal matrix.",
)
parser.add_argument("--gamma", type=float, default=1.0, help="Discount factor.")
parser.add_argument(
    "--actor_struct",
    type=str,
    default="quad-nomix",
    choices=["quad-lin", "quadratic", "quad-nomix"],
    help="Feature structure (actor). Currently available: "
    + "----quad-lin: quadratic-linear; "
    + "----quadratic: quadratic; "
    + "----quad-nomix: quadratic, no mixed terms.",
)


args = parser.parse_args([])

if not isinstance(args.state_init[0], int):
    for k in range(len(args.state_init)):
        args.state_init[k] = eval(args.state_init[k].replace("pi", str(np.pi)))


def update_globals_for_test(args=args):
    args.state_init = np.array(args.state_init)
    args.action_manual = np.array(args.action_manual)
    dim_state = 3
    args.dim_state = dim_state
    args.state_init = np.array(args.state_init)
    args.action_manual = np.array(args.action_manual)
    args.dim_state = 3
    args.dim_input = 2
    args.dim_output = args.dim_state
    args.dim_disturb = 0

    args.dim_R1 = args.dim_output + args.dim_input
    args.dim_R2 = args.dim_R1
    args.pred_step_size = args.dt * args.pred_step_size_multiplier

    args.R1 = np.diag(np.array(args.R1_diag))
    args.R2 = np.diag(np.array(args.R2_diag))
    return args
